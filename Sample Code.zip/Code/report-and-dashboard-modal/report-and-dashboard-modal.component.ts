import { Component, OnInit, Inject, ViewChildren, QueryList, ElementRef } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from 'src/app/services/common.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MxTranService } from 'src/app/mx-tran.service';
import { ShareStateService } from 'src/app/api/utils/share-state.service';
import { Subscription, Observable } from 'rxjs';
import { Store, AppState, selectLanguageState, shareReplay, OrganizationalElementsService, Swal } from '../../../store';
import { DashboardEntityDTO } from 'src/app/model/svcdao/dashboardEntityDTO';
import { PostReportAndDashboard, PutReportAndDashboard } from 'src/app/store/actions/report-and-dashboard.actions';

@Component({
    selector: 'app-report-and-dashboard-modal',
    templateUrl: './report-and-dashboard-modal.component.html',
    styleUrls: ['./report-and-dashboard-modal.component.css'],
})
export class ReportAndDashboardModalComponent implements OnInit {
    modelTitle: string = 'Create Template';
    templateForm: FormGroup;
    isObjLoaded: boolean = true;
    selectedType: string;
    isRTL: boolean;
    selectTypes = [
        { id: '1', key: 'report', value: 'Report' },
        { id: '2', key: 'dashboard', value: 'Dashboard' },
    ];
    selectedObjType: string = this.selectTypes[0].value;
    categories = [];
    languagesList = null;
    selectedLangs = new Set<string>();
    submitted: boolean = false;
    languageDuplicationError: string = null;
    existingValueMsg: boolean = false;
    @ViewChildren('selectLang') langSelects: QueryList<ElementRef<HTMLSelectElement>>;
    getAllLanguageState: Observable<any>;
    template = undefined;
    okButtonText: string = 'Create';
    selectedLanguageId: number;
    private subscriptions = new Subscription();

    constructor(
        public commonService: CommonService,
        @Inject(MAT_DIALOG_DATA) public data: any,
        public translation: MxTranService,
        private formBuilder: FormBuilder,
        private shareStateService: ShareStateService,
        private organizationalElementsService: OrganizationalElementsService,
        public dialogRef: MatDialogRef<ReportAndDashboardModalComponent>,
        private store: Store<AppState>
    ) {
        this.getAllLanguageState = this.store.select(selectLanguageState);
    }

    ngOnInit(): void {
        this.templateForm = this.formBuilder.group({
            templates: new FormArray([]),
        });

        if (this.data) {
            this.selectedType = this.data?.selectedType;
            this.modelTitle = this.data?.modelTitle;
            if (this.selectedType === 'copy' || this.selectedType === 'edit') {
                this.template = JSON.parse(JSON.stringify(this.data?.template));
                this.selectedObjType = this.data?.template?.dashboardType;
                this.loadLang();
            }
        }

        const subscribe2 = this.shareStateService?.selectedLanguage?.subscribe((res) => {
            if (res) {
                this.selectedLanguageId = res.id;
                this.isRTL = res.rtl;
            }
        });
        this.subscriptions.add(subscribe2);

        const subscribe3 = this.getAllLanguageState.pipe(shareReplay(1)).subscribe((state) => {
            if (state.initSuccess) {
                this.languagesList = state.languages;
                setTimeout(() => {
                    this.onChangeLanguage();
                }, 200);
                Swal.close();
            }
            if (state.error) {
                Swal.close();
                this.organizationalElementsService.errorAllert(state.error.error.title);
            }
        });
        this.subscriptions.add(subscribe3);

        if (this.selectTypes.length > 0) {
            this.isObjLoaded = false;
        }

        if (
            (this.data?.template && this.data?.modelTitle === 'Update template') ||
            this.modelTitle === this.translation.transLables('updateTemplate', 'Update template')
        ) {
            this.okButtonText = this.translation.transLables('update', 'Update');
        } else {
            this.okButtonText = this.translation.transLables('Create', 'Create');
        }

        if (this.selectedType === 'create') {
            this.addLanguage('1');
        }
    }

    onTemplateFormSubmit() {
        this.submitted = true;
        let data: DashboardEntityDTO;
        if (!this.checkDuplication()) {
            this.languageDuplicationError = null;
            if (this.templateForm.status == 'VALID') {
                //create new
                if (this.selectedType == 'create') {
                    let template = this.templateForm?.value?.templates;
                    template.forEach((element) => {
                        if (!element.dashboardType) {
                            element.dashboardType = this.selectedObjType;
                            element.dashboardCategoryId = this.data?.dashboardCategoryId;
                        }
                    });
                    const newTemplate = this.templateForm?.value?.templates[0];
                    newTemplate.translations = this.templateForm?.value?.templates?.filter(
                        (object) => object != newTemplate
                    );
                    data = newTemplate;
                    this.store.dispatch(PostReportAndDashboard({ body: data }));
                    // copy template
                } else if (this.template && this.selectedType === 'copy') {
                    let template = this.templateForm?.value?.templates;
                    let existingValues = this.template;
                    template.forEach((element) => {
                        if(element.languageId == 1) {
                            existingValues.name = element?.name;
                            existingValues.id = null;
                            existingValues.translations = [];
                            let binaryEnity = existingValues?.binaryEntityDTO;
                            binaryEnity.id = null;
                        } else {
                            const translation = existingValues?.translations.find(trans => trans.languageId == element.languageId)
                            if(translation){
                                translation.name = element.name
                            } else {
                                existingValues.translations.push({
                                    name: element?.name,
                                    languageId : element.languageId
                                })
                            }
                        }
                    });
                    data = existingValues;
                    this.store.dispatch(PostReportAndDashboard({ body: data }));
                } else {
                    // update template
                    let template = this.templateForm?.value?.templates;
                    let existingValues = this.template;
                    existingValues.name = template[0]?.name;
                    existingValues.languageId = template[0]?.languageId;
                    template.forEach((element) => {
                        if (element && element.languageId != template[0]?.languageId) {
                            let data = existingValues.translations?.find((x) => x?.languageId == element?.languageId);
                            if (data) {
                                let idx = existingValues?.translations?.indexOf(data);
                                existingValues.translations[idx].languageId = element?.languageId;
                                existingValues.translations[idx].name = element?.name;
                            } else {
                                existingValues.translations?.push(element);
                            }
                            data = null;
                        }
                    });
                    data = existingValues;
                    this.store.dispatch(PutReportAndDashboard({ body: data }));
                }
            }
        }
    }

    onModelHide() {
        this.dialogRef.close('cancel');
        this.resetForm();
    }

    resetForm() {
        this.submitted = false;
        this.languageDuplicationError = null;
        this.templateForm.reset();
        this.getFormAsArray.clear();
        this.addLanguage();
    }

    onChangeLanguage() {
        this.langSelects?.forEach((ls) => {
            const selectedVal = ls.nativeElement?.value;
            if (selectedVal) this.selectedLangs?.add(selectedVal);
        });
    }

    isSelected(id) {
        return this.selectedLangs.has(id.toString());
    }

    removeLanguage(template) {
        this.submitted = false;
        this.languageDuplicationError = null;
        this.selectedLangs.delete(template?.value?.languageId?.toString());
        const index = (this.templateForm.get('templates') as FormArray).controls.indexOf(template);
        this.getFormAsArray.removeAt(index);
        let idx = this.template?.translations?.find((x) => x.languageId == template?.value?.languageId);
        this.template?.translations?.splice(this.template?.translations?.indexOf(idx), 1);
    }

    addLanguage(language = null, id = null, name = null) {
        this.submitted = false;
        this.languageDuplicationError = null;
        if (!language) {
            const languages = this.languagesList?.find((lang) => {
                return !this.selectedLangs?.has(lang.id.toString());
            });

            if (languages) {
                language = languages.id;
            } else {
                return;
            }
        }
        if (!this.checkDuplication()) {
            this.getFormAsArray.push(
                this.formBuilder.group({
                    languageId: [language, Validators.required],
                    id: [id, []],
                    name: [name, [Validators.required]],
                })
            );
            setTimeout(() => {
                this.onChangeLanguage();
            }, 200);
        } else {
            this.languageDuplicationError = 'Please do not choose same language twice.';
        }
    }
    loadLang() {
        //Get Languages using store
        const sub2 = this.getAllLanguageState.pipe(shareReplay(1)).subscribe((state) => {
            if (state.initSuccess) {
                this.languagesList = state.languages;
                setTimeout(() => {
                    this.onChangeLanguage();
                    if (this.template) {
                        this.addLanguage(this.template.languageId, this.template.id, this.template.name);
                        this.template.translations?.forEach((item) => {
                            this.addLanguage(item.languageId, item.id, item.name);
                        });
                    } else {
                        this.addLanguage('1');
                    }
                }, 200);
            }
            if (state.error) {
                this.organizationalElementsService.errorAllert(state.error.error.title);
            }
        });
        this.subscriptions.add(sub2);
    }

    checkDuplication() {
        let languages = this.templateForm?.value?.templates?.map((item) => {
            return item.languageId;
        });
        let isDuplicate = languages?.some((item, idx) => {
            return languages.indexOf(item) != idx;
        });
        return isDuplicate;
    }

    ngOnDestroy() {
        this.subscriptions?.unsubscribe();
        delete this.modelTitle;
        delete this.templateForm;
        delete this.isObjLoaded;
        delete this.selectedType;
        delete this.isRTL;
        delete this.selectedObjType;
        delete this.categories;
        delete this.languagesList;
        delete this.selectedLangs;
        delete this.submitted;
        delete this.languageDuplicationError;
        delete this.existingValueMsg;
        delete this.selectTypes;
        delete this.langSelects;
        delete this.getAllLanguageState;
        delete this.template;
        delete this.okButtonText;
        delete this.selectedLanguageId;
    }
    get getFormControls() {
        return this.templateForm?.controls;
    }
    get getFormAsArray() {
        return this.getFormControls?.templates as FormArray;
    }
}
