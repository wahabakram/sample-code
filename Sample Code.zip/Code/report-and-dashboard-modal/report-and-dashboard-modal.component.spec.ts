import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportAndDashboardModalComponent } from './report-and-dashboard-modal.component';

describe('ReportAndDashboardModalComponent', () => {
  let component: ReportAndDashboardModalComponent;
  let fixture: ComponentFixture<ReportAndDashboardModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ReportAndDashboardModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportAndDashboardModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
